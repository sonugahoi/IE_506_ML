import pickle
with open('users.pck', 'wb') as file:
    pickle.dump([],file)
   

