•	Developed sign up, log in and forget password features by importing pickle and random module
•	Implemented principle of Object-Oriented Programming in python using class and constructor
•	Users are asked security questions after more than three trials for resetting the password


# The following are the features:
1. Sign up
2. Log in
3. forgot password

# Sign up
A new user account is created by asking
username
password
phone number
2 security Questions

Password will be valid only if password
1. should be at least 7 characters long
2. should have at least 2 letters
3. should have at least one digit
4. should not contain any whitespace

if password length >= 12, it will show strong password

# Login
Enter username:
if account is blocked do not proceed further

Enter password:
3 wrong password attempts
block the user account

if password is correct:
print welcome message

# forgot password
Enter username:
if account is blocked, don't proceed further

Show the security questions:
if correctly answered, show the password

Otherwise send an OTP to the mobile number




